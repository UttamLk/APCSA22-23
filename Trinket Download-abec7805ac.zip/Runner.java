/*
 * Activity 2.5.2
 *
 * The runner for the PhraseSolverGame
 */
public class Runner
{
  public static void main(String[] args) 
  {
    PhraseSolver p = new PhraseSolver(); 
    p.play();
  }

} 
